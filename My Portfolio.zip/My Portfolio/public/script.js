function toggleMenu() {
    const menuItems = document.getElementById('menuItems');
    const currentDisplay = menuItems.style.display;
    menuItems.style.display = currentDisplay === 'none' ? 'flex' : 'none';
}

// Close menu when clicking outside
document.addEventListener('click', function(event) {
    const menuItems = document.getElementById('menuItems');
    const menuButton = document.querySelector('.menu-btn');
    
    if (!event.target.closest('.nav-menu')) {
        menuItems.style.display = 'none';
    }
});

// Handle window resize
window.addEventListener('resize', function() {
    if (window.innerWidth > 768) {
        document.getElementById('menuItems').style.display = 'none';
    }
});

// Add Intersection Observer for scroll animations
const animateOnScroll = () => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = 1;
        entry.target.style.transform = 'translateY(0)';
      }
    });
  });

  document.querySelectorAll('.animate-on-scroll').forEach((el) => {
    el.style.opacity = 0;
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'all 0.6s ease-out';
    observer.observe(el);
  });
}

// Add hover effect to project cards
const addProjectHover = () => {
  document.querySelectorAll('.project-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      card.style.setProperty('--mouse-x', `${x}px`);
      card.style.setProperty('--mouse-y', `${y}px`);
    });
  });
}

// Initialize animations
document.addEventListener('DOMContentLoaded', () => {
  animateOnScroll();
  addProjectHover();
  
  // Add typing effect to your name
  const name = document.querySelector('h1');
  if (name) {
    name.style.animation = 'text-pop 0.6s ease-out both';
  }
});
